// نظام المياه: محيط (WaterPlane) وأنهار (River) بسطح موجي وانعكاس للسماء وتوهج الشمس.
// الملف water.bin تنتجه الأداة tools/bake_water.py. إن فشل تجميع الشيدر لا تتعطل اللعبة (تُتجاهل المياه).
use macroquad::miniquad::{BlendFactor, BlendState, BlendValue, Comparison, Equation, PipelineParams, UniformDesc, UniformType};
use macroquad::prelude::*;

fn plane_cells(hf: &crate::world::HeightField, lvl: f32, col: [u8; 4]) -> Vec<Mesh> {
    let st = 2usize;
    let n = hf.n;
    let mut out: Vec<Mesh> = Vec::new();
    let mut verts: Vec<Vertex> = Vec::new();
    let mut idx: Vec<u16> = Vec::new();
    let mut iy = 0usize;
    while iy + st < n {
        let mut ix = 0usize;
        while ix + st < n {
            let (h00, h10, h01, h11) = (hf.hat(ix, iy), hf.hat(ix + st, iy), hf.hat(ix, iy + st), hf.hat(ix + st, iy + st));
            if h00 < lvl || h10 < lvl || h01 < lvl || h11 < lvl {
                let x0 = hf.ox + ix as f32 * hf.cell;
                let x1 = hf.ox + (ix + st) as f32 * hf.cell;
                let z0 = -(hf.oy + iy as f32 * hf.cell);
                let z1 = -(hf.oy + (iy + st) as f32 * hf.cell);
                let b = verts.len() as u16;
                for (px, pz) in [(x0, z1), (x1, z1), (x1, z0), (x0, z0)] {
                    verts.push(Vertex { position: vec3(px, lvl, pz), uv: vec2(0.0, 0.0), color: col, normal: vec4(0.0, 1.0, 0.0, 0.0) });
                }
                idx.extend_from_slice(&[b, b + 2, b + 1, b, b + 3, b + 2]);
                if verts.len() > 59000 {
                    out.push(Mesh { vertices: std::mem::take(&mut verts), indices: std::mem::take(&mut idx), texture: None });
                }
            }
            ix += st;
        }
        iy += st;
    }
    if !verts.is_empty() { out.push(Mesh { vertices: verts, indices: idx, texture: None }); }
    out
}

pub struct Water {
    meshes: Vec<Mesh>,
    mat: Material,
    pub level: f32,
}

impl Water {
    pub fn load() -> Option<Water> {
        let path = crate::world::map_path("water.bin")?;
        let b = std::fs::read(path).ok()?;
        if b.len() < 8 || &b[0..4] != b"WAT1" { return None; }
        let rd = |o: usize| u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]);
        let rf = |o: usize| f32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]);
        let n = rd(4) as usize;
        let mut p = 8usize;
        let mut meshes = Vec::new();
        let mut level = -1.0e9f32;
        for _ in 0..n {
            if p + 12 > b.len() { break; }
            let (nv, ni, lvl) = (rd(p) as usize, rd(p + 4) as usize, rf(p + 8));
            p += 12;
            let vend = p + nv * 16;
            let iend = vend + ni * 2;
            if iend > b.len() { break; }
            if lvl > -1.0e8 { level = level.max(lvl); }
            let mut verts = Vec::with_capacity(nv);
            for i in 0..nv {
                let o = p + i * 16;
                verts.push(Vertex {
                    position: vec3(rf(o), rf(o + 4), rf(o + 8)),
                    uv: vec2(0.0, 0.0),
                    color: [b[o + 12], b[o + 13], b[o + 14], b[o + 15]],
                    normal: vec4(0.0, 1.0, 0.0, 0.0),
                });
            }
            let mut idx = Vec::with_capacity(ni);
            for i in 0..ni { idx.push(u16::from_le_bytes([b[vend + i * 2], b[vend + i * 2 + 1]])); }
            p = iend;
            if nv == 4 && lvl > -1.0e8 {
                // المحيط: نبني سطح الماء فقط فوق خلايا التضاريس التي تقع تحت مستواه (لا مستوى لانهائي)
                let col = [verts[0].color[0], verts[0].color[1], verts[0].color[2], 255];
                if let Some(hf) = crate::world::terrain_hf() {
                    meshes.extend(plane_cells(&hf, lvl, col));
                    continue;
                }
            }
            meshes.push(Mesh { vertices: verts, indices: idx, texture: None });
        }
        if meshes.is_empty() { return None; }
        crate::world::set_water_level(level);
        let fs = format!(
            "#version 100\nprecision highp float;\n{}\n{}",
            include_str!("../assets/shaders/common.glsl"),
            include_str!("../assets/shaders/water.frag")
        );
        let mat = load_material(
            ShaderSource::Glsl { vertex: include_str!("../assets/shaders/water.vert"), fragment: &fs },
            MaterialParams {
                pipeline_params: PipelineParams {
                    depth_test: Comparison::LessOrEqual,
                    depth_write: false,
                    color_blend: Some(BlendState::new(
                        Equation::Add,
                        BlendFactor::Value(BlendValue::SourceAlpha),
                        BlendFactor::OneMinusValue(BlendValue::SourceAlpha),
                    )),
                    ..Default::default()
                },
                uniforms: vec![
                    UniformDesc::new("VP", UniformType::Mat4),
                    UniformDesc::new("sun_dir", UniformType::Float3),
                    UniformDesc::new("cam_pos", UniformType::Float3),
                    UniformDesc::new("fog_col", UniformType::Float3),
                    UniformDesc::new("misc", UniformType::Float4),
                ],
                textures: vec![],
            },
        )
        .ok()?;
        Some(Water { meshes, mat, level })
    }

    pub fn draw(&self, vp: Mat4, cp: Vec3) {
        let e = crate::world::get_env();
        gl_use_material(&self.mat);
        self.mat.set_uniform("VP", vp);
        self.mat.set_uniform("sun_dir", vec3(e[0], e[1], e[2]));
        self.mat.set_uniform("cam_pos", cp);
        self.mat.set_uniform("fog_col", vec3(e[3], e[4], e[5]));
        self.mat.set_uniform("misc", vec4(e[6], e[7], 0.0, 0.0));
        for m in &self.meshes { draw_mesh(m); }
    }
}
