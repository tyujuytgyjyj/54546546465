// نظام المياه: محيط (WaterPlane) وأنهار (River) بسطح موجي وانعكاس للسماء وتوهج الشمس.
// الملف water.bin تنتجه الأداة tools/bake_water.py. إن فشل تجميع الشيدر لا تتعطل اللعبة (تُتجاهل المياه).
use macroquad::miniquad::{Comparison, PipelineParams, UniformDesc, UniformType};
use macroquad::prelude::*;

#[derive(Clone, Copy)]
struct ShorePoint {
    x: f32,
    z: f32,
    ground_y: f32,
}

// Embedded here so the compiled water path cannot silently keep loading a different assets/shaders copy.
const WATER_VERTEX_SHADER: &str = r##"#version 100
attribute vec3 position;
attribute vec2 texcoord;
attribute vec4 color0;
attribute vec4 normal;

varying highp vec3 wp;
varying mediump vec4 col;

uniform mat4 VP;
uniform vec4 misc; // x = time, y = true sun elevation

void main() {
    float t = misc.x;
    vec2 p = position.xz;
    float q1 = dot(p, vec2(0.6, 0.8)) * 0.11 + t * 1.25;
    float q2 = dot(p, vec2(-0.8, 0.5)) * 0.21 - t * 1.65;
    float q3 = dot(p, vec2(0.3, -0.95)) * 0.42 + t * 2.10;

    float depth = clamp(color0.a / 255.0, 0.0, 1.0);
    float shore_fade = smoothstep(0.015, 0.38, depth);
    float wave_height = (
        sin(q1) * 0.085 +
        sin(q2) * 0.034 +
        sin(q3) * 0.014
    ) * shore_fade;

    vec3 displaced = position;
    displaced.y += wave_height;
    wp = displaced;
    col = color0 / 255.0;
    gl_Position = VP * vec4(displaced, 1.0);
}
"##;
const WATER_COMMON_SHADER: &str = r##"float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p){
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p){
    float a = 0.5; float s = 0.0;
    for (int k = 0; k < 4; k++) { s += a * vnoise(p); p = p * 2.03 + vec2(17.0, 9.0); a *= 0.5; }
    return s;
}

// Physically-inspired Rayleigh + Mie atmospheric sky with realistic Sunrise, Golden Hour, Sunset, Twilight & Starry Night
vec3 skyc(vec3 d, vec3 sun, float t, bool clouds){
    float y = max(d.y, 0.001);
    float sy = sun.y; // -1.0 (midnight) .. 0.0 (horizon sunrise/sunset) .. +0.88 (noon)

    // Blend factors for Day, Golden-Hour/Twilight, and Night
    float day_f = smoothstep(-0.08, 0.28, sy);
    float twilight_f = smoothstep(-0.22, 0.02, sy) * (1.0 - smoothstep(0.04, 0.38, sy));
    float night_f = 1.0 - smoothstep(-0.18, 0.04, sy);

    // Zenith color: crisp Rayleigh blue by day -> deep royal indigo at sunset -> midnight cosmos at night
    vec3 zen_day = vec3(0.045, 0.19, 0.58);
    vec3 zen_twi = vec3(0.035, 0.055, 0.20);
    vec3 zen_ngt = vec3(0.006, 0.010, 0.028);
    vec3 zen = mix(zen_ngt, zen_day, day_f);
    zen = mix(zen, zen_twi, twilight_f * 0.85);

    // Base horizon color: atmospheric haze by day -> warm amber/rose/violet at sunset -> deep navy at night
    vec3 sun_flat = normalize(vec3(sun.x, 0.0, sun.z) + vec3(1e-5, 0.0, 0.0));
    vec3 d_flat = normalize(vec3(d.x, 0.0, d.z) + vec3(1e-5, 0.0, 0.0));
    float azim = dot(d_flat, sun_flat) * 0.5 + 0.5; // 1.0 toward sun horizon, 0.0 opposite horizon (Belt of Venus)

    vec3 hor_day = vec3(0.52, 0.72, 0.95);
    vec3 hor_ngt = vec3(0.018, 0.030, 0.068);
    // Sunset/Sunrise directional horizon: fiery crimson-gold toward the sun, dusty magenta-violet opposite (Belt of Venus)
    vec3 hor_sun_side = vec3(1.55, 0.36, 0.07);
    vec3 hor_anti_side = vec3(0.32, 0.18, 0.38);
    vec3 hor_twi = mix(hor_anti_side, hor_sun_side, pow(azim, 1.6));

    vec3 hor = mix(hor_ngt, hor_day, day_f);
    hor = mix(hor, hor_twi, twilight_f);

    // Multi-band Rayleigh/Mie vertical gradient (with golden middle band during sunrise/sunset)
    vec3 c = mix(hor, zen, pow(y, 0.42));
    vec3 mid_glow = vec3(1.15, 0.55, 0.16) * pow(azim, 2.2) * exp(-y * 4.5) * (1.0 - exp(-y * 18.0));
    c += mid_glow * twilight_f * 1.35;

    // Solar Mie scattering (Henyey-Greenstein-inspired forward scatter + solar disc)
    float sd = max(dot(d, sun), 0.0);
    float sun_vis = smoothstep(-0.08, 0.02, sy);
    vec3 mie_col = mix(vec3(1.65, 0.42, 0.09), vec3(1.05, 0.88, 0.65), smoothstep(0.0, 0.35, sy));
    c += mie_col * pow(sd, 4.0) * (0.24 + 0.45 * twilight_f) * sun_vis;
    c += mie_col * pow(sd, 32.0) * (0.55 + 0.65 * twilight_f) * sun_vis;
    c += vec3(2.8, 2.2, 1.6) * smoothstep(0.9993, 0.99985, sd) * 3.5 * sun_vis;

    // Moon & Starfield at night
    vec3 moon_dir = normalize(vec3(-sun.x, max(-sun.y, 0.18), -sun.z));
    float md = max(dot(d, moon_dir), 0.0);
    c += vec3(0.25, 0.38, 0.65) * pow(md, 18.0) * 0.35 * night_f;
    c += vec3(1.4, 1.55, 1.8) * smoothstep(0.99945, 0.99985, md) * 1.8 * night_f;

    if (clouds && night_f > 0.02 && d.y > 0.04) {
        vec2 sp = d.xz / (d.y + 0.35) * 160.0;
        vec2 si = floor(sp);
        vec2 sf = fract(sp) - 0.5;
        float sh = hash(si);
        if (sh > 0.965) {
            float r2 = dot(sf, sf);
            float twinkle = 0.65 + 0.35 * sin(t * 2.5 + sh * 90.0);
            float star = exp(-r2 * 55.0) * smoothstep(0.965, 0.999, sh) * twinkle;
            vec3 scol = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.9, 0.75), fract(sh * 37.0));
            c += scol * star * night_f * smoothstep(0.04, 0.28, d.y) * 1.6;
        }
    }

    // Volumetric-lit multi-layer clouds
    if (clouds && d.y > 0.005) {
        vec2 p = d.xz / (d.y + 0.13) * 0.80 + vec2(t * 0.009, t * 0.0035);
        float n = fbm(p * 1.25);
        float cov = smoothstep(0.46, 0.79, n);
        if (cov > 0.005) {
            float dens = fbm(p * 3.2 + 2.7);
            float grad = fbm(p * 1.25 + sun_flat.xz * 0.08) - n;
            float self_sh = clamp(0.55 + grad * 2.8, 0.15, 1.0);

            vec3 cld_top_day = vec3(1.02, 0.99, 0.96);
            vec3 cld_bot_day = vec3(0.55, 0.63, 0.75);
            vec3 cld_top_twi = vec3(1.35, 0.48, 0.16);
            vec3 cld_bot_twi = vec3(0.16, 0.12, 0.25);
            vec3 cld_top_ngt = vec3(0.05, 0.07, 0.13);
            vec3 cld_bot_ngt = vec3(0.015, 0.022, 0.045);

            vec3 ctop = mix(cld_top_ngt, cld_top_day, day_f);
            ctop = mix(ctop, cld_top_twi, twilight_f);
            vec3 cbot = mix(cld_bot_ngt, cld_bot_day, day_f);
            cbot = mix(cbot, cld_bot_twi, twilight_f);

            vec3 cc = mix(cbot, ctop, clamp(dens * self_sh, 0.0, 1.0));
            // Silver/golden lining near sun
            cc += mie_col * pow(sd, 5.0) * (1.1 - dens * 0.6) * (0.45 + 0.75 * twilight_f) * sun_vis;
            c = mix(c, cc, cov * smoothstep(0.005, 0.20, d.y) * 0.92);
        }
    }

    if (d.y < 0.0) {
        vec3 gnd_c = mix(vec3(0.01, 0.015, 0.03), vec3(0.22, 0.26, 0.22), day_f);
        gnd_c = mix(gnd_c, vec3(0.25, 0.12, 0.08), twilight_f);
        c = mix(hor, gnd_c, clamp(-d.y * 6.5, 0.0, 1.0));
    }
    return max(c, vec3(0.0));
}

// ACES Filmic Tonemapping with rich contrast and natural highlight roll-off
vec3 tonemap(vec3 x){
    x *= 1.08;
    vec3 a = x * (2.51 * x + 0.03);
    vec3 b = x * (2.43 * x + 0.59) + 0.14;
    return pow(clamp(a / b, 0.0, 1.0), vec3(1.0 / 2.2));
}
"##;
const WATER_FRAGMENT_SHADER: &str = r##"varying highp vec3 wp;
varying mediump vec4 col;
uniform vec3 sun_dir;
uniform vec3 cam_pos;
uniform vec3 fog_col;
uniform vec4 misc; // x = time, y = true sun elevation

void main() {
    float t = misc.x;
    vec3 true_sun = normalize(vec3(sun_dir.x, misc.y, sun_dir.z));
    vec2 p = wp.xz;

    // Analytical wave gradients match the vertex displacement.
    float q1 = dot(p, vec2(0.6, 0.8)) * 0.11 + t * 1.25;
    float q2 = dot(p, vec2(-0.8, 0.5)) * 0.21 - t * 1.65;
    float q3 = dot(p, vec2(0.3, -0.95)) * 0.42 + t * 2.10;
    vec2 gradient = vec2(0.0);
    gradient += vec2(0.6, 0.8) * cos(q1) * (0.085 * 0.11);
    gradient += vec2(-0.8, 0.5) * cos(q2) * (0.034 * 0.21);
    gradient += vec2(0.3, -0.95) * cos(q3) * (0.014 * 0.42);
    gradient += (vec2(
        vnoise(p * 0.65 + t * 0.045),
        vnoise(p * 0.65 - t * 0.035 + 4.7)
    ) - 0.5) * 0.022;

    vec3 n = normalize(vec3(-gradient.x, 1.0, -gradient.y));
    vec3 vdir = normalize(cam_pos - wp);
    float ndv = max(dot(n, vdir), 0.0);
    float fresnel = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);

    vec3 reflected_dir = reflect(-vdir, n);
    reflected_dir.y = abs(reflected_dir.y);
    vec3 reflection = skyc(reflected_dir, true_sun, t, true);

    // Water absorption: shallow turquoise transitions to deep blue-green.
    float depth = clamp(col.a, 0.0, 1.0);
    float deepness = smoothstep(0.08, 0.96, depth);
    vec3 shallow_water = vec3(0.018, 0.30, 0.32);
    vec3 deep_water = vec3(0.004, 0.045, 0.082);
    vec3 authored_tint = pow(max(col.rgb, vec3(0.006)), vec3(2.2));
    vec3 body_color = mix(shallow_water, deep_water, deepness);
    body_color = mix(body_color, authored_tint, 0.24);

    // Keep the body readable head-on, then let the sky take over at grazing angles.
    vec3 color = mix(body_color, reflection, clamp(0.14 + fresnel * 0.84, 0.0, 0.92));

    // Moving shoreline foam is driven by the depth mask stored in vertex alpha.
    float shore = 1.0 - smoothstep(0.02, 0.62, depth);
    float foam_noise = fbm(p * 0.34 + vec2(t * 0.075, -t * 0.052));
    float foam = smoothstep(0.58, 0.82, foam_noise + shore * 0.56);
    foam *= smoothstep(0.16, 0.78, shore);
    color = mix(color, vec3(0.72, 0.86, 0.84), foam * 0.72);

    // Tight solar glints and a softer secondary highlight on wave crests.
    float sun_glint = pow(max(dot(reflected_dir, true_sun), 0.0), 190.0)
        * smoothstep(-0.05, 0.22, misc.y);
    float crest = pow(max(dot(n, normalize(true_sun + vdir)), 0.0), 72.0);
    color += vec3(2.0, 1.72, 1.38) * sun_glint;
    color += vec3(0.08, 0.16, 0.18) * crest * 0.18;

    // Water haze is intentionally restrained so the surface does not become milky.
    float distance_to_camera = length(cam_pos - wp);
    float haze = 1.0 - exp(-distance_to_camera * 0.00042);
    vec3 aerial = pow(max(fog_col, vec3(0.0)), vec3(2.2));
    color = mix(color, aerial, clamp(haze, 0.0, 0.34));

    gl_FragColor = vec4(tonemap(color), 1.0);
}
"##;

fn plane_cells(hf: &crate::world::HeightField, lvl: f32, col: [u8; 4]) -> Vec<Mesh> {
    // Clip each terrain cell against the water plane. This prevents complete quads
    // from being drawn over dry land when only one corner is below sea level.
    let st = 1usize;
    let n = hf.n;
    let mut out: Vec<Mesh> = Vec::new();
    let mut verts: Vec<Vertex> = Vec::new();
    let mut idx: Vec<u16> = Vec::new();

    let mut iy = 0usize;
    while iy + st < n {
        let mut ix = 0usize;
        while ix + st < n {
            let h00 = hf.hat(ix, iy);
            let h10 = hf.hat(ix + st, iy);
            let h01 = hf.hat(ix, iy + st);
            let h11 = hf.hat(ix + st, iy + st);

            if h00 < lvl || h10 < lvl || h01 < lvl || h11 < lvl {
                let x0 = hf.ox + ix as f32 * hf.cell;
                let x1 = hf.ox + (ix + st) as f32 * hf.cell;
                let z0 = -(hf.oy + iy as f32 * hf.cell);
                let z1 = -(hf.oy + (iy + st) as f32 * hf.cell);
                let corners = [
                    ShorePoint { x: x0, z: z1, ground_y: h01 },
                    ShorePoint { x: x1, z: z1, ground_y: h11 },
                    ShorePoint { x: x1, z: z0, ground_y: h10 },
                    ShorePoint { x: x0, z: z0, ground_y: h00 },
                ];
                let mut polygon: Vec<ShorePoint> = Vec::with_capacity(6);
                let mut previous = corners[3];
                let mut previous_inside = previous.ground_y < lvl;

                for current in corners {
                    let current_inside = current.ground_y < lvl;
                    if current_inside != previous_inside {
                        let denom = current.ground_y - previous.ground_y;
                        if denom.abs() > 1.0e-6 {
                            let t = ((lvl - previous.ground_y) / denom).clamp(0.0, 1.0);
                            polygon.push(ShorePoint {
                                x: previous.x + (current.x - previous.x) * t,
                                z: previous.z + (current.z - previous.z) * t,
                                ground_y: lvl,
                            });
                        }
                    }
                    if current_inside {
                        polygon.push(current);
                    }
                    previous = current;
                    previous_inside = current_inside;
                }

                if polygon.len() >= 3 {
                    if verts.len() + polygon.len() > 59000 && !verts.is_empty() {
                        out.push(Mesh {
                            vertices: std::mem::take(&mut verts),
                            indices: std::mem::take(&mut idx),
                            texture: None,
                        });
                    }

                    let base = verts.len() as u16;
                    for point in &polygon {
                        // Vertex alpha is a depth mask for the shader, not transparency.
                        let depth = (lvl - point.ground_y).max(0.0);
                        let depth_mask = (depth / 1.35).clamp(0.0, 1.0);
                        verts.push(Vertex {
                            position: vec3(point.x, lvl, point.z),
                            uv: vec2(point.x, point.z),
                            color: [col[0], col[1], col[2], (depth_mask * 255.0) as u8],
                            normal: vec4(0.0, 1.0, 0.0, 0.0),
                        });
                    }

                    // Reverse the X/Z polygon winding so the triangles face +Y.
                    for i in 1..polygon.len() - 1 {
                        idx.extend_from_slice(&[base, base + (i + 1) as u16, base + i as u16]);
                    }
                }
            }
            ix += st;
        }
        iy += st;
    }

    if !verts.is_empty() {
        out.push(Mesh { vertices: verts, indices: idx, texture: None });
    }
    out
}

pub struct Water {
    meshes: Vec<Mesh>,
    mat: Material,
    pub level: f32,
}

impl Water {
    pub fn load() -> Option<Water> {
        let path = crate::world::map_path("water.bin")?;
        let b = std::fs::read(path).ok()?;
        if b.len() < 8 || &b[0..4] != b"WAT1" { return None; }
        let rd = |o: usize| u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]);
        let rf = |o: usize| f32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]);
        let n = rd(4) as usize;
        let mut p = 8usize;
        let mut meshes = Vec::new();
        let mut level = -1.0e9f32;
        for _ in 0..n {
            if p + 12 > b.len() { break; }
            let (nv, ni, lvl) = (rd(p) as usize, rd(p + 4) as usize, rf(p + 8));
            p += 12;
            let vend = p + nv * 16;
            let iend = vend + ni * 2;
            if iend > b.len() { break; }
            if lvl > -1.0e8 { level = level.max(lvl); }
            let mut verts = Vec::with_capacity(nv);
            for i in 0..nv {
                let o = p + i * 16;
                verts.push(Vertex {
                    position: vec3(rf(o), rf(o + 4), rf(o + 8)),
                    uv: vec2(0.0, 0.0),
                    color: [b[o + 12], b[o + 13], b[o + 14], b[o + 15]],
                    normal: vec4(0.0, 1.0, 0.0, 0.0),
                });
            }
            let mut idx = Vec::with_capacity(ni);
            for i in 0..ni { idx.push(u16::from_le_bytes([b[vend + i * 2], b[vend + i * 2 + 1]])); }
            p = iend;
            if nv == 4 && lvl > -1.0e8 {
                // المحيط: نبني سطح الماء فقط فوق خلايا التضاريس التي تقع تحت مستواه (لا مستوى لانهائي)
                let col = [verts[0].color[0], verts[0].color[1], verts[0].color[2], 255];
                if let Some(hf) = crate::world::terrain_hf() {
                    meshes.extend(plane_cells(&hf, lvl, col));
                    continue;
                }
            }
            meshes.push(Mesh { vertices: verts, indices: idx, texture: None });
        }
        if meshes.is_empty() { return None; }
        crate::world::set_water_level(level);
        let fs = format!(
            "#version 100\nprecision highp float;\n{}\n{}",
            WATER_COMMON_SHADER,
            WATER_FRAGMENT_SHADER
        );
        let mat = load_material(
            ShaderSource::Glsl { vertex: WATER_VERTEX_SHADER, fragment: &fs },
            MaterialParams {
                pipeline_params: PipelineParams {
                    depth_test: Comparison::LessOrEqual,
                    depth_write: true,
                    ..Default::default()
                },
                uniforms: vec![
                    UniformDesc::new("VP", UniformType::Mat4),
                    UniformDesc::new("sun_dir", UniformType::Float3),
                    UniformDesc::new("cam_pos", UniformType::Float3),
                    UniformDesc::new("fog_col", UniformType::Float3),
                    UniformDesc::new("misc", UniformType::Float4),
                ],
                textures: vec![],
            },
        )
        .ok()?;
        Some(Water { meshes, mat, level })
    }

    pub fn draw(&self, vp: Mat4, cp: Vec3) {
        let e = crate::world::get_env();
        gl_use_material(&self.mat);
        self.mat.set_uniform("VP", vp);
        self.mat.set_uniform("sun_dir", vec3(e[0], e[1], e[2]));
        self.mat.set_uniform("cam_pos", cp);
        self.mat.set_uniform("fog_col", vec3(e[3], e[4], e[5]));
        self.mat.set_uniform("misc", vec4(e[6], e[7], 0.0, 0.0));
        for m in &self.meshes { draw_mesh(m); }
    }
}
