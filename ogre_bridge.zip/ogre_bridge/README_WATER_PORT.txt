APEX.drive — OGRE Next water and SSR integration
=================================================
Uses OGRE-Next HLMS PBS Refractive mode and the OGRE ScreenSpaceReflections
compositor. The official RefractionsWorkspace is retained as fallback.

Required OGRE Samples/Media directories:
- 2.0/scripts/materials/Common and Common/HLSL
- 2.0/scripts/materials/ScreenSpaceReflections and ScreenSpaceReflections/HLSL

Keep water_media beside CMakeLists.txt and build Release x64 with the same
OGRE-Next 3.0 SDK. The DLL path is expected to be <project>/build/Release.

Frame flow:
1. SSR GBuffer/reflections of opaque world objects.
2. Capture opaque scene in rttOpaque.
3. Refractive water uses captured colour + resolved depth in queue 200.
4. APEX HUD is drawn in queue 99 after water.
5. rttFinal is copied to the render window.

The water uses three generated 512x512 seamless normal scales, two animated
PBS detail-normal layers, IOR 1.333, screen-space refraction, three Gerstner
wave bands, Fresnel sky fallback, sun glints and animated shoreline foam.
Dawn, dusk and the sky system remain unchanged.
The full source repository was used read-only; no write was made there.
This source archive excludes build directories and stale DLL/OBJ binaries.
Build and in-game verification on Windows is still required.

APEX.drive — Sky, Sand and Road Surface Correction
===================================================

- Sky cloud coordinates use viewing-direction mapping, avoiding stretched radial streaks near the horizon.
- The 2K cumulus layer uses warped multi-scale billow forms, edge erosion and internal shading. The cirrus layer is thinner.
- Sand uses isotropic multi-scale grain, without directional sine bands, with reduced normal strength and tiling.
- Road asphalt also uses isotropic fine aggregate instead of directional waves, with a separate subtle road-normal family.
- Water rendering, vehicle physics and sunrise/sunset curves are unchanged.

Source and archive structure were checked. A local Windows/MSVC OGRE build and in-game visual test are still required.

APEX.drive — Wind, Anti-Aliasing, Fence Alpha and Sky Seam Fix
===============================================================

Sky
---
- Cloud longitude UVs are unwrapped around the screen-centre camera ray, preventing
  triangles from interpolating through the 0/1 equirectangular seam.
- Cloud alpha fades near the zenith, reducing the polar singularity and the radial
  streak pattern seen in the latest editor screenshot.
- Existing atmospheric gradients, sun, moon, stars, dawn/dusk and water reflection
  colour path remain in place.

Anti-aliasing and texture filtering
-----------------------------------
- Client defaults to 4x MSAA; --msaa8 requests 8x and --no-msaa disables it.
- OGRE retries window creation without MSAA if the requested mode is rejected.
- A CPU-generated full mip chain is uploaded for mesh textures, cloud maps and
  normal maps so anisotropic filtering can work across distance.

Fences and vegetation
---------------------
- Cutout detection uses a regular 128x128 probe grid and distinguishes binary
  transparency from soft translucent glass.
- bake_props.py encodes alphaTest as a high-bit texture marker. props.rs strips
  the marker before indexing and forwards a per-submesh alpha-cutout vertex tag.
- Tree/palm/shrub/plant species receive per-vertex wind weights based on height.
  The foliage canopy sways more than the trunk; fences stay static and perforated.
- Existing baked props remain readable; the runtime alpha-sampling fallback still
  applies when they have not yet been re-baked with the updated tool.

Wind and ocean
--------------
- A slowly varying coastal wind direction/gust drives grass-card sway and
  height-weighted foliage sway.
- The same wind signal changes Gerstner wave direction, speed and amplitude.
- Shoreline foam receives multi-scale breakup and slow wind advection.
- This is a lightweight visual wind field, not a full CFD solver or vehicle
  aerodynamic-force simulation. No wind force is applied to vehicle handling.

Preserved
---------
- Water rendering/reflection/compositor architecture stays in place.
- Tyre grip, rolling resistance, suspension and vehicle dynamics stay unchanged.
- Sunrise/sunset colour curves stay unchanged.

Validation
----------
Source and ZIP structure were checked. A local Windows/MSVC OGRE build and an
in-game visual validation were not available here.
