APEX.drive — native OGRE water integration
============================================
Uses OGRE-Next native HLMS PBS Refractive mode and the official
RefractionsWorkspace / RefractionsWorkspaceMsaa compositor.

Extract the archive and keep water_media beside CMakeLists.txt. Build Release
x64 using the same OGRE-Next 3.0 SDK used by the game. The bridge resolves
water_media relative to the DLL located at <project>/build/Release.

Render order: capture scene queues through 98, refract water in queue 200,
then draw APEX HUD queue 99.

Water: three seamless generated 512x512 normal maps, two animated PBS detail
normal layers, IOR 1.333, screen-space refraction, Gerstner swell, Fresnel
sky contribution, sun glints, animated shoreline foam and generated tangents.

Existing sky, dawn and dusk are unchanged. The full source repository was
read-only and no files were uploaded there.

This archive intentionally excludes stale build/Release DLL/OBJ binaries.
