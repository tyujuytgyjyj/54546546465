APEX.drive — OGRE Next water and SSR integration
=================================================
Uses OGRE-Next HLMS PBS Refractive mode and the OGRE ScreenSpaceReflections
compositor. The official RefractionsWorkspace is retained as fallback.

Required OGRE Samples/Media directories:
- 2.0/scripts/materials/Common and Common/HLSL
- 2.0/scripts/materials/ScreenSpaceReflections and ScreenSpaceReflections/HLSL

Keep water_media beside CMakeLists.txt and build Release x64 with the same
OGRE-Next 3.0 SDK. The DLL path is expected to be <project>/build/Release.

Frame flow:
1. SSR GBuffer/reflections of opaque world objects.
2. Capture opaque scene in rttOpaque.
3. Refractive water uses captured colour + resolved depth in queue 200.
4. APEX HUD is drawn in queue 99 after water.
5. rttFinal is copied to the render window.

The water uses three generated 512x512 seamless normal scales, two animated
PBS detail-normal layers, IOR 1.333, screen-space refraction, three Gerstner
wave bands, Fresnel sky fallback, sun glints and animated shoreline foam.
Dawn, dusk and the sky system remain unchanged.
The full source repository was used read-only; no write was made there.
This source archive excludes build directories and stale DLL/OBJ binaries.
Build and in-game verification on Windows is still required.

APEX.drive — Sky and Beach Correction
======================================

This revision responds to the in-game screenshots:
- Cloud UVs now follow the viewing direction on an equirectangular sky map. This removes the old fixed-altitude ground-plane projection that stretched cloud textures into radial streaks near the horizon.
- The 2K cumulus texture uses multi-scale domain warping, rounded billow lobes, edge erosion and internal light/shadow variation. The cirrus layer is thinner and less opaque.
- Sand no longer contains directional sine waves. It uses isotropic multi-scale grain, lower normal strength and a lower tiling multiplier to avoid ruler-straight bands.
- Asphalt remains on its own material family and is not assigned the sand normal map.

Water, vehicle physics and sunrise/sunset curves are unchanged.

The updated source and archive structure are checked, but a local Windows/MSVC OGRE build and in-game visual test are still required.
