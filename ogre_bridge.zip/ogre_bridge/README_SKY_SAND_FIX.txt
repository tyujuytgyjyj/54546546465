APEX.drive — Sky and Beach Correction
======================================

This revision responds to the in-game screenshots:
- Cloud UVs now follow the viewing direction on an equirectangular sky map. This removes the old fixed-altitude ground-plane projection that stretched cloud textures into radial streaks near the horizon.
- The 2K cumulus texture uses multi-scale domain warping, rounded billow lobes, edge erosion and internal light/shadow variation. The cirrus layer is thinner and less opaque.
- Sand no longer contains directional sine waves. It uses isotropic multi-scale grain, lower normal strength and a lower tiling multiplier to avoid ruler-straight bands.
- Asphalt remains on its own material family and is not assigned the sand normal map.

Water, vehicle physics and sunrise/sunset curves are unchanged.

The updated source and archive structure are checked, but a local Windows/MSVC OGRE build and in-game visual test are still required.
