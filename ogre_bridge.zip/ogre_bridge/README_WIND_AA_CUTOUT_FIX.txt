APEX.drive — Wind, Anti-Aliasing, Fence Alpha and Sky Seam Fix
===============================================================

Sky
---
- Cloud longitude UVs are unwrapped around the screen-centre camera ray, preventing
  triangles from interpolating through the 0/1 equirectangular seam.
- Cloud alpha fades near the zenith, reducing the polar singularity and the radial
  streak pattern seen in the latest editor screenshot.
- Existing atmospheric gradients, sun, moon, stars, dawn/dusk and water reflection
  colour path remain in place.

Anti-aliasing and texture filtering
-----------------------------------
- Client defaults to 4x MSAA; --msaa8 requests 8x and --no-msaa disables it.
- OGRE retries window creation without MSAA if the requested mode is rejected.
- A CPU-generated full mip chain is uploaded for mesh textures, cloud maps and
  normal maps so anisotropic filtering can work across distance.

Fences and vegetation
---------------------
- Cutout detection uses a regular 128x128 probe grid and distinguishes binary
  transparency from soft translucent glass.
- bake_props.py encodes alphaTest as a high-bit texture marker. props.rs strips
  the marker before indexing and forwards a per-submesh alpha-cutout vertex tag.
- Tree/palm/shrub/plant species receive per-vertex wind weights based on height.
  The foliage canopy sways more than the trunk; fences stay static and perforated.
- Existing baked props remain readable; the runtime alpha-sampling fallback still
  applies when they have not yet been re-baked with the updated tool.

Wind and ocean
--------------
- A slowly varying coastal wind direction/gust drives grass-card sway and
  height-weighted foliage sway.
- The same wind signal changes Gerstner wave direction, speed and amplitude.
- Shoreline foam receives multi-scale breakup and slow wind advection.
- This is a lightweight visual wind field, not a full CFD solver or vehicle
  aerodynamic-force simulation. No wind force is applied to vehicle handling.

Preserved
---------
- Water rendering/reflection/compositor architecture stays in place.
- Tyre grip, rolling resistance, suspension and vehicle dynamics stay unchanged.
- Sunrise/sunset colour curves stay unchanged.

Validation
----------
Source and ZIP structure were checked. A local Windows/MSVC OGRE build and an
in-game visual validation were not available here.
