@echo off
setlocal EnableExtensions
set "BRIDGE_DIR=%~dp0"
set "BUILD_DIR=%BRIDGE_DIR%build"

where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: CMake was not found. Install CMake and the Visual Studio C++ workload.
  exit /b 1
)

if not exist "C:\OgreSDK\include\OGRE" (
  echo ERROR: OGRE headers not found at C:\OgreSDK\include\OGRE
  exit /b 1
)

if not exist "C:\biqfr\build_ogre_scripts-v3-0\Ogre\ogre-next\OgreMain\include" (
  echo ERROR: OGRE-Next source tree was not found at the path configured in CMakeLists.txt.
  exit /b 1
)

echo [1/2] Configuring OGRE bridge...
cmake -S "%BRIDGE_DIR%" -B "%BUILD_DIR%" -A x64
if errorlevel 1 exit /b 1

echo [2/2] Building Release bridge...
cmake --build "%BUILD_DIR%" --config Release --clean-first --parallel
if errorlevel 1 exit /b 1

if not exist "%BUILD_DIR%\Release\ogre_bridge.dll" (
  echo ERROR: Build completed but ogre_bridge.dll was not found in build\Release.
  exit /b 1
)
if not exist "%BUILD_DIR%\Release\ogre_bridge.lib" (
  echo ERROR: ogre_bridge.lib was not found in build\Release.
  exit /b 1
)

echo.
echo BUILD SUCCESS:
echo %BUILD_DIR%\Release\ogre_bridge.dll
certutil -hashfile "%BUILD_DIR%\Release\ogre_bridge.dll" SHA256
echo.
echo NEXT: rebuild the Rust client. Updated build.rs copies this DLL beside crashdrive.exe.
exit /b 0
