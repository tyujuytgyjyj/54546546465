varying highp vec3 wp;
varying lowp vec4 col;
uniform vec3 sun_dir;
uniform vec3 cam_pos;
uniform vec3 fog_col;
uniform vec4 misc; // x = time, y = true sun elevation
void main() {
    float t = misc.x;
    vec3 true_sun = normalize(vec3(sun_dir.x, misc.y, sun_dir.z));
    vec2 p = wp.xz;
    // سطح موجي: جمع موجات جيبية + ضوضاء
    vec2 g = vec2(0.0);
    g += vec2(0.6, 0.8) * cos(dot(p, vec2(0.6, 0.8)) * 0.9 + t * 1.3) * 0.030;
    g += vec2(-0.8, 0.5) * cos(dot(p, vec2(-0.8, 0.5)) * 1.7 + t * 1.9) * 0.020;
    g += vec2(0.3, -0.95) * cos(dot(p, vec2(0.3, -0.95)) * 3.1 + t * 2.6) * 0.012;
    g += (vec2(vnoise(p * 0.8 + t * 0.3), vnoise(p * 0.8 - t * 0.25 + 5.0)) - 0.5) * 0.05;
    vec3 n = normalize(vec3(-g.x, 1.0, -g.y));
    vec3 vdir = normalize(cam_pos - wp);
    float fres = 0.02 + 0.98 * pow(1.0 - max(dot(n, vdir), 0.0), 5.0);
    vec3 r = reflect(-vdir, n);
    r.y = abs(r.y);
    vec3 refl = skyc(r, true_sun, t, true);
    vec3 deep = pow(max(col.rgb, vec3(0.0)), vec3(2.2));
    vec3 colr = mix(deep, refl, clamp(fres * 0.9 + 0.08, 0.0, 1.0));
    float sunS = pow(max(dot(r, true_sun), 0.0), 220.0) * smoothstep(-0.05, 0.2, misc.y);
    colr += vec3(2.2, 1.9, 1.5) * sunS;
    float d = length(cam_pos - wp);
    float f = 1.0 - exp(-d * 0.00105);
    vec3 aerial_col = pow(max(fog_col, vec3(0.0)), vec3(2.2));
    colr = mix(colr, aerial_col, clamp(f, 0.0, 1.0));
    gl_FragColor = vec4(tonemap(colr), 0.80 + 0.15 * fres);
}
