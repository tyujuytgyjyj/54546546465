#version 100
attribute vec3 position;
attribute vec2 texcoord;
attribute vec4 color0;
attribute vec4 normal;
varying highp vec3 wp;
varying lowp vec4 col;
uniform mat4 VP;
void main() {
    wp = position;
    col = color0 / 255.0;
    gl_Position = VP * vec4(position, 1.0);
}
